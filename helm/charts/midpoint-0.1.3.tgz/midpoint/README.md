# Evolveum Midpoint helm chart

Added extraInitContainers

Based on https://github.com/cfi2017/helm-charts/tree/main/charts/midpoint 
